# Hayy V2 Polished Frontend

A polished React/Vite frontend prototype for Hayy.

## Included pages

Public:
- Landing page
- Login
- Signup
- Onboarding

App:
- Dashboard
- Rooms
- Room detail
- Live room
- Referral modal
- Referrals
- Profile
- Referral host dashboard
- Recruiter dashboard
- Settings

## Run locally

```bash
npm install
npm run dev
```

## Deploy on Vercel

- Framework preset: Vite
- Build command: npm run build
- Output directory: dist
- Root directory: ./
