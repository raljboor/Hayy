
import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowRight,
  Bell,
  Bookmark,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronRight,
  CircleDot,
  Compass,
  Crown,
  Eye,
  Filter,
  Globe2,
  Handshake,
  HeartHandshake,
  Home,
  Layers3,
  Lock,
  Mail,
  Menu,
  MessageCircle,
  Mic,
  MonitorUp,
  Play,
  Plus,
  Radio,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Star,
  User,
  UserRoundCheck,
  Users,
  Video,
  WandSparkles,
  X,
  XCircle,
  Zap
} from "lucide-react";
import "./styles.css";

const rooms = [
  {
    id: "r1",
    tag: "FOUNDING ROOM",
    category: "Career Access",
    title: "How to Get Referred Into Corporate Roles in Canada",
    host: "Hayy Community",
    hostRole: "Founding career room",
    date: "Thursday · 7:00 PM EST",
    attendees: 82,
    speakers: 8,
    status: "Open",
    type: "Live Q&A",
    description: "Meet professionals inside target companies, ask questions, and learn how to turn a conversation into a warm intro."
  },
  {
    id: "r2",
    tag: "OPERATIONS",
    category: "Operations",
    title: "Breaking Into Amazon, Logistics & Program Management",
    host: "Ops Professionals",
    hostRole: "Managers and operators",
    date: "Next week",
    attendees: 41,
    speakers: 5,
    status: "Waitlist",
    type: "Coffee Chat",
    description: "A focused room for people targeting operations, supply chain, logistics, launch, and program roles."
  },
  {
    id: "r3",
    tag: "NEWCOMERS",
    category: "Newcomers",
    title: "Career Access for International Professionals",
    host: "Referral Hosts",
    hostRole: "International professionals",
    date: "Coming soon",
    attendees: 29,
    speakers: 4,
    status: "Notify me",
    type: "Panel",
    description: "A practical room for newcomers building their first warm network in Canada."
  },
  {
    id: "r4",
    tag: "PRODUCT",
    category: "Tech",
    title: "Product, Data & Software Career Room",
    host: "Tech Hosts",
    hostRole: "Product and engineering mentors",
    date: "May 9 · 6:30 PM EST",
    attendees: 56,
    speakers: 6,
    status: "Open",
    type: "Live Room",
    description: "Meet product, data, design, and software professionals through live discussion."
  },
  {
    id: "r5",
    tag: "FINANCE",
    category: "Finance",
    title: "Finance & Banking Referral Night",
    host: "Finance Hosts",
    hostRole: "Banking and analyst mentors",
    date: "May 12 · 7:30 PM EST",
    attendees: 38,
    speakers: 4,
    status: "Open",
    type: "Referral Night",
    description: "Understand how to build trust before requesting a referral in finance and banking."
  },
  {
    id: "r6",
    tag: "CONSULTING",
    category: "Consulting",
    title: "Consulting Coffee Chat Room",
    host: "Strategy Circle",
    hostRole: "Consultants and analysts",
    date: "May 15 · 8:00 PM EST",
    attendees: 25,
    speakers: 3,
    status: "Waitlist",
    type: "Coffee Chat",
    description: "Practice story-led introductions and get honest advice from consulting professionals."
  }
];

const referrals = [
  {
    id: "ref1",
    name: "Nadia K.",
    avatar: "NK",
    target: "Program Manager · Amazon",
    company: "Amazon",
    status: "Pending",
    type: "Coffee chat",
    lastUpdated: "2h ago",
    note: "Looking for insight into PM and operations roles before applying."
  },
  {
    id: "ref2",
    name: "Yousef A.",
    avatar: "YA",
    target: "Supply Chain Analyst · RBC",
    company: "RBC",
    status: "Accepted",
    type: "Referral review",
    lastUpdated: "Yesterday",
    note: "Strong analytics background and Canadian internship experience."
  },
  {
    id: "ref3",
    name: "Maya H.",
    avatar: "MH",
    target: "Operations Analyst · Shopify",
    company: "Shopify",
    status: "Declined",
    type: "Referral",
    lastUpdated: "3d ago",
    note: "Needs more role alignment before referral."
  },
  {
    id: "ref4",
    name: "Omar J.",
    avatar: "OJ",
    target: "Business Analyst · Deloitte",
    company: "Deloitte",
    status: "Completed",
    type: "Coffee chat",
    lastUpdated: "1w ago",
    note: "Completed intro call and received next-step advice."
  }
];

const hosts = [
  { name: "Aisha K.", avatar: "AK", role: "Director of Product", company: "Stripe", capacity: "2 chats open", tags: ["Product", "Strategy"] },
  { name: "Omar H.", avatar: "OH", role: "Engineering Manager", company: "Meta", capacity: "1 referral open", tags: ["Engineering", "Management"] },
  { name: "Leila M.", avatar: "LM", role: "Head of Design", company: "Airbnb", capacity: "3 chats open", tags: ["Design", "Portfolio"] },
  { name: "Khalid A.", avatar: "KA", role: "Senior Product Manager", company: "Google", capacity: "2 referrals open", tags: ["PM", "Growth"] }
];

const candidates = [
  { name: "Sara M.", avatar: "SM", role: "Operations Analyst", source: "Khalid A.", tags: ["Excel", "Power BI", "Logistics"], fit: "High", status: "Referred" },
  { name: "Omar A.", avatar: "OA", role: "Product Analyst", source: "Aisha K.", tags: ["SQL", "Research", "UX"], fit: "Medium", status: "Shortlisted" },
  { name: "Lina F.", avatar: "LF", role: "Industrial Engineer", source: "Leila M.", tags: ["Lean", "Data", "Simulation"], fit: "High", status: "Applied" },
  { name: "Maha S.", avatar: "MS", role: "Product Designer", source: "Khalid A.", tags: ["Design", "Systems", "Research"], fit: "High", status: "Interviewed" }
];

function HayyMark({ size = 40 }) {
  return (
    <svg className="hayy-mark" width={size} height={size} viewBox="0 0 120 120" aria-hidden="true">
      <defs>
        <linearGradient id="hayyBronze" x1="12" y1="8" x2="110" y2="116" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#E4C17A" />
          <stop offset="0.45" stopColor="#B57A39" />
          <stop offset="1" stopColor="#5B351E" />
        </linearGradient>
      </defs>
      <path d="M60 8 L69 17 L60 26 L51 17 Z" fill="url(#hayyBronze)" opacity=".98" />
      <path d="M60 47 L68 55 L60 63 L52 55 Z" fill="url(#hayyBronze)" opacity=".88" />
      <path d="M21 55 L30 46 L39 55 L30 64 Z" fill="url(#hayyBronze)" opacity=".76" />
      <path d="M99 55 L90 46 L81 55 L90 64 Z" fill="url(#hayyBronze)" opacity=".76" />
      <path d="M60 23 C39 38 28 48 28 67 L28 83 L45 93 L45 68 C45 58 51 50 60 44 C69 50 75 58 75 68 L75 93 L92 83 L92 67 C92 48 81 38 60 23Z" fill="none" stroke="url(#hayyBronze)" strokeWidth="8" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M60 38 C47 48 41 57 41 72 L41 101 L60 112 L79 101 L79 72 C79 57 73 48 60 38Z" fill="none" stroke="url(#hayyBronze)" strokeWidth="7" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M29 69 C42 70 52 76 60 86 C68 76 78 70 91 69" fill="none" stroke="url(#hayyBronze)" strokeWidth="7" strokeLinecap="round" />
      <path d="M60 84 L60 111" stroke="url(#hayyBronze)" strokeWidth="7" strokeLinecap="round" />
    </svg>
  );
}

function Logo({ compact = false }) {
  return (
    <div className={"logo " + (compact ? "compact" : "")}>
      <HayyMark size={compact ? 34 : 54} />
      <span>HAYY</span>
    </div>
  );
}

function Button({ children, variant = "primary", onClick, className = "", type = "button" }) {
  return (
    <button type={type} onClick={onClick} className={`btn ${variant} ${className}`}>
      {children}
    </button>
  );
}

function Badge({ children, tone = "gold" }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

function Avatar({ initials, className = "" }) {
  return <span className={`avatar ${className}`}>{initials}</span>;
}

function PublicHeader({ setPage, page }) {
  const [open, setOpen] = useState(false);
  const nav = [
    ["rooms", "Rooms"],
    ["landing", "How it works"],
    ["host", "For hosts"],
    ["recruiter", "Recruiters"]
  ];

  return (
    <header className="public-header">
      <button className="brand-button" onClick={() => setPage("landing")}><Logo compact /></button>
      <nav className="desktop-nav">
        {nav.map(([key, label]) => (
          <button key={label} onClick={() => setPage(key)} className={page === key ? "active" : ""}>{label}</button>
        ))}
      </nav>
      <div className="desktop-actions">
        <button className="ghost-nav" onClick={() => setPage("login")}>Log in</button>
        <Button onClick={() => setPage("signup")}>Join founding room</Button>
      </div>
      <button className="mobile-menu" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X /> : <Menu />}</button>
      {open && (
        <div className="mobile-panel">
          {nav.map(([key, label]) => <button key={label} onClick={() => { setPage(key); setOpen(false); }}>{label}</button>)}
          <button onClick={() => { setPage("login"); setOpen(false); }}>Log in</button>
          <button onClick={() => { setPage("signup"); setOpen(false); }}>Join founding room</button>
        </div>
      )}
    </header>
  );
}

function Landing({ setPage }) {
  return (
    <>
      <section className="hero">
        <div className="hero-geometry hero-geometry-one"></div>
        <div className="hero-geometry hero-geometry-two"></div>

        <div className="hero-copy">
          <div className="launch-pill">
            <Sparkles size={16} />
            Founding community now forming
          </div>
          <div className="hero-logo">
            <HayyMark size={110} />
            <span>HAYY</span>
          </div>
          <h1>Where careers come alive.</h1>
          <p>
            A live career neighborhood where ambitious professionals meet real people, build warm connections,
            and earn trusted referrals before applying.
          </p>
          <div className="hero-actions">
            <Button onClick={() => setPage("signup")}>Join the first Hayy room <ArrowRight size={18} /></Button>
            <Button variant="secondary" onClick={() => setPage("host")}>Become a referral host</Button>
          </div>

          <div className="mini-proof">
            <div><Radio /> Live conversations</div>
            <div><Handshake /> Real referrals</div>
            <div><ShieldCheck /> Trusted access</div>
          </div>
        </div>

        <LiveRoomShowcase setPage={setPage} />
      </section>

      <section className="proof-strip">
        <div>
          <strong>1,248+</strong>
          <span>early members</span>
        </div>
        <div>
          <strong>64%</strong>
          <span>pilot attendance target</span>
        </div>
        <div>
          <strong>18</strong>
          <span>referral requests generated</span>
        </div>
        <div>
          <strong>4.9/5</strong>
          <span>room experience goal</span>
        </div>
      </section>

      <section className="problem-solution">
        <article className="large-card dark-card">
          <Badge>THE PROBLEM</Badge>
          <h2>Cold applications hide real people.</h2>
          <p>Most candidates are not ignored because they lack potential. They are ignored because nobody gets to hear their story, see their energy, or trust them before the resume filter.</p>
        </article>
        <article className="large-card light-card">
          <Badge>THE HAYY WAY</Badge>
          <h2>Access should start with a conversation.</h2>
          <p>Hayy turns networking into live rooms, warm introductions, and referral requests built on real interactions — not spammy messages or empty job boards.</p>
        </article>
      </section>

      <HowItWorks />

      <section className="section">
        <SectionHeading eyebrow="Upcoming rooms" title="Focused career rooms with people who can actually help." action={<button onClick={() => setPage("rooms")}>View all rooms <ArrowRight size={16}/></button>} />
        <div className="cards-grid three">
          {rooms.slice(0, 3).map(room => <RoomCard key={room.id} room={room} setPage={setPage} />)}
        </div>
      </section>

      <section className="host-section">
        <div className="host-copy">
          <Badge>FOR REFERRAL HOSTS</Badge>
          <h2>Share your path. Open the door for someone else.</h2>
          <p>Hosts choose their availability, accept only the requests they trust, and support candidates through coffee chats, resume feedback, or referrals.</p>
          <Button onClick={() => setPage("host")}>Open host dashboard <ArrowRight size={18}/></Button>
        </div>
        <HostProfileCard />
        <ReferralPreview />
      </section>

      <section className="recruiter-band">
        <div>
          <Badge>FOR RECRUITERS</Badge>
          <h2>Host better hiring conversations before applications flood in.</h2>
          <p>Create Q&A rooms, meet referred candidates, and see talent before the application stage.</p>
        </div>
        <Button onClick={() => setPage("recruiter")}>Explore recruiter tools <ArrowRight size={18}/></Button>
      </section>

      <section className="final-cta">
        <div>
          <HayyMark size={66} />
          <h2>Build your network the human way.</h2>
          <p>Join the founding Hayy community and be part of the first live career rooms.</p>
        </div>
        <Button onClick={() => setPage("signup")}>Request founding access <ArrowRight size={18}/></Button>
      </section>
    </>
  );
}

function LiveRoomShowcase({ setPage }) {
  const people = [
    ["Aisha K.", "Host", "AK", true],
    ["Omar H.", "Speaker", "OH", true],
    ["Leila M.", "Speaker", "LM", true],
    ["You", "Listening", "YU", false],
    ["Maha S.", "Designer", "MS", true],
    ["Zayd R.", "Listener", "ZR", false]
  ];

  return (
    <div className="live-showcase">
      <div className="showcase-top">
        <span><CircleDot size={14}/> Live room preview</span>
        <span>28:34</span>
      </div>

      <div className="showcase-header">
        <div>
          <Badge tone="live">LIVE</Badge>
          <h3>Product Leaders in Tech</h3>
          <p>Building products people love.</p>
        </div>
        <div className="overlap-avatars">
          {["AK","OH","LM"].map(a => <Avatar initials={a} className="tiny" key={a}/>)}
          <span>+24</span>
        </div>
      </div>

      <div className="video-grid">
        {people.map(([name, role, initials, speaking]) => (
          <div key={name} className={`video-tile ${speaking ? "speaking" : ""}`}>
            <div className="tile-face"><Avatar initials={initials}/></div>
            <div className="tile-info">
              <strong>{name}</strong>
              <span>{role}</span>
            </div>
            {speaking && <div className="sound-bars"><i></i><i></i><i></i></div>}
          </div>
        ))}
      </div>

      <div className="question-card">
        <div>
          <HayyMark size={32}/>
          <strong>What’s a career move that shaped your path the most?</strong>
        </div>
        <Button className="dark-button" onClick={() => setPage("liveRoom")}>Enter room</Button>
      </div>
    </div>
  );
}

function HowItWorks() {
  const steps = [
    ["Join a live room", "Discover curated rooms hosted by professionals inside companies and industries you admire.", <Mic />],
    ["Share your story", "Introduce yourself, ask specific questions, and build trust through authentic conversation.", <MessageCircle />],
    ["Request a referral", "When the fit is real, request a coffee chat, resume review, or warm referral.", <Handshake />],
    ["Track follow-ups", "Keep your rooms, requests, and next steps organized in one calm workspace.", <ShieldCheck />]
  ];

  return (
    <section className="section how">
      <div className="center-heading">
        <Badge>HOW HAYY WORKS</Badge>
        <h2>From room to referral in four human steps.</h2>
      </div>
      <div className="steps">
        {steps.map(([title, body, icon], index) => (
          <article className="step" key={title}>
            <span className="step-count">0{index + 1}</span>
            <div className="step-icon">{icon}</div>
            <h3>{title}</h3>
            <p>{body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function SectionHeading({ eyebrow, title, action }) {
  return (
    <div className="section-heading">
      <div>
        <p>{eyebrow}</p>
        <h2>{title}</h2>
      </div>
      {action}
    </div>
  );
}

function RoomCard({ room, setPage }) {
  return (
    <article className="room-card">
      <div className="room-top">
        <Badge>{room.tag}</Badge>
        <span>{room.type}</span>
      </div>
      <h3>{room.title}</h3>
      <p>{room.description}</p>
      <div className="host-line-mini">
        <Avatar initials={room.host.slice(0, 2).toUpperCase()} className="small" />
        <div>
          <strong>{room.host}</strong>
          <span>{room.hostRole}</span>
        </div>
      </div>
      <div className="room-meta">
        <span><CalendarDays size={15}/> {room.date}</span>
        <span><Users size={15}/> {room.attendees} attending</span>
        <span><Mic size={15}/> {room.speakers} speakers</span>
      </div>
      <Button variant={room.status === "Open" ? "primary" : "secondary"} onClick={() => setPage("roomDetail")}>{room.status}</Button>
    </article>
  );
}

function HostProfileCard() {
  return (
    <article className="host-profile-card">
      <div className="host-cover">
        <div className="host-pattern"></div>
        <Avatar initials="KA" className="xl"/>
        <div>
          <h3>Khalid Al Saeed</h3>
          <p>Senior Product Manager @ Google</p>
          <span>Referral host since 2023</span>
        </div>
      </div>
      <div className="host-stats">
        <div><strong>24</strong><span>Hosted rooms</span></div>
        <div><strong>87</strong><span>Referrals made</span></div>
        <div><strong>213</strong><span>People helped</span></div>
      </div>
    </article>
  );
}

function ReferralPreview() {
  return (
    <article className="referral-preview">
      <div className="preview-heading">
        <strong>Referral request preview</strong>
        <span>2h ago</span>
      </div>
      <div className="request-profile">
        <Avatar initials="MS" className="small"/>
        <div>
          <strong>Maha Salman</strong>
          <span>Product Designer</span>
        </div>
      </div>
      <p>Hi Khalid — I really enjoyed your room on scaling design teams. I’d love to request a referral for a Product Designer role on your team.</p>
      <div className="request-details">
        <div><span>Role</span><strong>Product Designer</strong></div>
        <div><span>Company</span><strong>Google</strong></div>
      </div>
      <div className="request-actions">
        <Button variant="secondary">Decline</Button>
        <Button>Support with referral</Button>
      </div>
    </article>
  );
}

function AuthPage({ type, setPage }) {
  const signup = type === "signup";
  return (
    <main className="auth-layout">
      <section className="auth-panel">
        <Logo />
        <div>
          <h1>{signup ? "Join Hayy" : "Welcome back."}</h1>
          <p>{signup ? "Request access to the founding career rooms and start building warm professional connections." : "Log in to manage rooms, referrals, and follow-ups."}</p>
        </div>
        {signup && <label>Full name<input placeholder="Your name" /></label>}
        <label>Email<input type="email" placeholder="you@email.com" /></label>
        <label>Password<input type="password" placeholder="••••••••" /></label>
        {signup && (
          <>
            <label>I am a<select><option>Job seeker</option><option>Referral host</option><option>Recruiter / employer</option><option>Community partner</option></select></label>
            <label>Target role or industry<input placeholder="Operations, product, finance..." /></label>
          </>
        )}
        <Button onClick={() => setPage(signup ? "onboarding" : "dashboard")}>{signup ? "Create account" : "Log in"} <ArrowRight size={18}/></Button>
        <button className="text-link" onClick={() => setPage(signup ? "login" : "signup")}>
          {signup ? "Already have an account? Log in" : "Need an account? Join Hayy"}
        </button>
      </section>

      <section className="auth-story">
        <HayyMark size={120}/>
        <h2>More than a resume. More than a job.</h2>
        <p>Meet real people, show your story, and build the kind of trust that creates opportunity.</p>
        <div className="story-list">
          <span><Radio/> Live career rooms</span>
          <span><Handshake/> Referral tracking</span>
          <span><UserRoundCheck/> Warm introductions</span>
        </div>
      </section>
    </main>
  );
}

function Onboarding({ setPage }) {
  return (
    <main className="onboarding">
      <div className="onboarding-heading">
        <Badge>ONBOARDING</Badge>
        <h1>Tell Hayy what kind of access you need.</h1>
        <p>We’ll personalize rooms, hosts, and referral opportunities around your career target.</p>
      </div>

      <div className="progress"><span></span></div>

      <div className="onboarding-grid">
        <FormCard icon={<Compass/>} title="1. Career target">
          <label>Target role<input placeholder="Operations Analyst, PM, SWE..." /></label>
          <label>Target companies<input placeholder="Amazon, Shopify, RBC..." /></label>
          <label>Location<input placeholder="Toronto, Canada" /></label>
          <label>Experience level<select><option>Early career</option><option>Student</option><option>New grad</option><option>Mid career</option><option>Career switcher</option></select></label>
        </FormCard>
        <FormCard icon={<Sparkles/>} title="2. Your story">
          <label>Short bio<textarea placeholder="Tell hosts who you are and what you are building toward." /></label>
          <label>Key skills<input placeholder="Power BI, operations, SQL..." /></label>
          <label>LinkedIn URL<input placeholder="linkedin.com/in/..." /></label>
        </FormCard>
        <FormCard icon={<Handshake/>} title="3. Support needed">
          <div className="chips">
            {["Coffee chats", "Referrals", "Resume feedback", "Interview prep", "Company insight", "Networking practice"].map(item => <button key={item}>{item}</button>)}
          </div>
          <div className="upload-zone">
            <MonitorUp/>
            <strong>Video intro placeholder</strong>
            <span>Add later</span>
          </div>
        </FormCard>
      </div>

      <Button onClick={() => setPage("dashboard")} className="finish-button">Finish onboarding <ArrowRight size={18}/></Button>
    </main>
  );
}

function FormCard({ icon, title, children }) {
  return (
    <article className="form-card">
      <div className="form-card-title">
        <div className="ornament-icon">{icon}</div>
        <h3>{title}</h3>
      </div>
      {children}
    </article>
  );
}

function AppShell({ page, setPage, children }) {
  const nav = [
    ["dashboard", "Home", <Home/>],
    ["rooms", "Rooms", <Mic/>],
    ["referrals", "Referrals", <Handshake/>],
    ["profile", "Profile", <User/>],
    ["host", "Host dashboard", <HeartHandshake/>],
    ["recruiter", "Recruiter", <BriefcaseBusiness/>],
    ["settings", "Settings", <Settings/>]
  ];

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <button className="brand-button sidebar-brand" onClick={() => setPage("landing")}><Logo compact /></button>
        <nav>
          {nav.map(([key, label, icon]) => (
            <button key={key} className={page === key ? "active" : ""} onClick={() => setPage(key)}>
              {React.cloneElement(icon, { size: 18 })} {label}
            </button>
          ))}
        </nav>
        <div className="sidebar-callout">
          <HayyMark size={44}/>
          <strong>Founding access</strong>
          <p>Invite 3 friends and unlock priority rooms.</p>
        </div>
      </aside>
      <section className="app-content">
        {children}
      </section>
    </main>
  );
}

function AppTop({ eyebrow, title, action }) {
  return (
    <div className="app-top">
      <div>
        <p>{eyebrow}</p>
        <h1>{title}</h1>
      </div>
      {action}
    </div>
  );
}

function Dashboard({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Dashboard" title="Welcome back, Rakan" action={<Button onClick={() => setPage("rooms")}>Find a room <ArrowRight size={18}/></Button>} />

      <Stats stats={[["6","Referral requests"],["3","Accepted chats"],["2","Rooms joined"],["1","Host intro"]]} />

      <div className="app-grid two">
        <Panel title="Suggested rooms" action={<button onClick={() => setPage("rooms")}>View all</button>}>
          {rooms.slice(0,3).map(room => <MiniRoom key={room.id} room={room} setPage={setPage}/>)}
        </Panel>
        <Panel title="Pending follow-ups" action={<Bell size={18}/>}>
          {referrals.slice(0,3).map(ref => <ReferralMini key={ref.id} ref={ref}/>)}
        </Panel>
      </div>

      <div className="app-grid two">
        <Panel title="Recommended hosts">
          <div className="host-mini-grid">
            {hosts.map(host => <HostMini key={host.name} host={host}/>)}
          </div>
        </Panel>
        <Panel title="Profile completion">
          <Checklist items={["Add bio", "Add skills", "Add resume", "Add LinkedIn", "Add video intro"]}/>
        </Panel>
      </div>
    </AppShell>
  );
}

function RoomsPage({ page, setPage }) {
  const [query, setQuery] = useState("");
  const filtered = useMemo(() => rooms.filter(room =>
    room.title.toLowerCase().includes(query.toLowerCase()) ||
    room.category.toLowerCase().includes(query.toLowerCase())
  ), [query]);

  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Rooms" title="Live career rooms" action={<Button><Plus size={18}/> Suggest a room</Button>} />
      <div className="search-row">
        <div className="search-box"><Search size={18}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search rooms, hosts, topics..." /></div>
        <Button variant="secondary"><Filter size={18}/> Filters</Button>
      </div>
      <div className="chips filter-chips">
        {["All", "Operations", "Tech", "Finance", "Newcomers", "Product", "Consulting", "Canada", "MENA community"].map(item => <button key={item}>{item}</button>)}
      </div>
      <div className="cards-grid two">
        {filtered.map(room => <RoomCard key={room.id} room={room} setPage={setPage}/>)}
      </div>
    </AppShell>
  );
}

function RoomDetail({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <button className="back-link" onClick={() => setPage("rooms")}>← Back to rooms</button>
      <section className="detail-hero">
        <Badge>FOUNDING ROOM</Badge>
        <h1>How to Get Referred Into Corporate Roles in Canada</h1>
        <p>Meet professionals inside target companies, ask questions, and learn how to turn a conversation into a warm intro.</p>
        <div className="detail-meta">
          <span><CalendarDays/> Thursday · 7:00 PM EST</span>
          <span><Users/> 82 signed up</span>
          <span><Mic/> 8 speakers</span>
          <span><Globe2/> Online</span>
        </div>
        <div className="hero-actions left">
          <Button onClick={() => setPage("liveRoom")}>Join room <ArrowRight size={18}/></Button>
          <Button variant="secondary"><Bookmark size={18}/> Save room</Button>
        </div>
      </section>

      <div className="app-grid two">
        <Panel title="Agenda">
          <Timeline items={["Welcome + room rules", "Host introductions", "Live Q&A", "Breakout networking", "Referral request instructions"]}/>
        </Panel>
        <Panel title="Hosts">
          {hosts.map(host => <HostLine key={host.name} host={host}/>)}
        </Panel>
      </div>

      <div className="app-grid two">
        <Panel title="Who should join">
          <div className="chips compact">
            {["Early-career professionals", "International students", "Newcomers", "Corporate role seekers", "Referral learners"].map(item => <span key={item}>{item}</span>)}
          </div>
        </Panel>
        <Panel title="Room rules">
          <Checklist items={["Be respectful", "Do not spam referral requests", "Ask specific questions", "Follow up professionally"]}/>
        </Panel>
      </div>
    </AppShell>
  );
}

function LiveRoom({ page, setPage }) {
  const [modal, setModal] = useState(false);
  const people = [
    ["Aisha K.", "Host", "AK"], ["Omar H.", "Speaker", "OH"], ["Leila M.", "Speaker", "LM"], ["Khalid A.", "Speaker", "KA"],
    ["You", "Listening", "YU"], ["Maha S.", "Listening", "MS"], ["Zayd R.", "Listening", "ZR"], ["Nadia K.", "Listening", "NK"]
  ];

  return (
    <AppShell page={page} setPage={setPage}>
      <div className="live-layout">
        <section className="live-stage">
          <div className="live-top">
            <div>
              <Badge tone="live">LIVE NOW</Badge>
              <h1>Breaking Into Corporate Roles in Canada</h1>
            </div>
            <span>28:34</span>
          </div>
          <div className="live-grid">
            {people.map(([name, role, initials], index) => (
              <div className={`live-card ${index < 4 ? "is-speaking" : ""}`} key={name}>
                <Avatar initials={initials}/>
                <strong>{name}</strong>
                <span>{role}</span>
                {index < 4 && <div className="sound-bars"><i></i><i></i><i></i></div>}
              </div>
            ))}
          </div>
          <div className="live-controls">
            <button><Mic/> Mute</button>
            <button><Video/> Video</button>
            <button><Radio/> Raise hand</button>
            <button><MessageCircle/> Ask</button>
            <button className="gold" onClick={() => setModal(true)}><Handshake/> Request referral</button>
            <button className="danger" onClick={() => setPage("rooms")}><X/> Leave</button>
          </div>
        </section>

        <aside className="live-side">
          <Panel title="Questions">
            {["How do referrals actually work?", "What makes someone referral-ready?", "Should I message before or after applying?", "How do I follow up without being annoying?"].map(q => <div className="question" key={q}>{q}</div>)}
            <div className="chat-input"><input placeholder="Ask a question..." /><Send size={18}/></div>
          </Panel>
          <Panel title="Raised hands">
            {["Maha S.", "Zayd R.", "Nadia K."].map(name => <div className="queue-row" key={name}><span>{name}</span><Button variant="secondary">Invite</Button></div>)}
          </Panel>
        </aside>
      </div>
      {modal && <ReferralModal onClose={() => setModal(false)}/>}
    </AppShell>
  );
}

function ReferralModal({ onClose }) {
  return (
    <div className="modal-backdrop">
      <section className="modal">
        <button className="modal-close" onClick={onClose}><X/></button>
        <Badge>REFERRAL REQUEST</Badge>
        <h2>Request a warm intro</h2>
        <p>Keep it specific, respectful, and easy to say yes to.</p>
        <label>Select host<select><option>Aisha K. · Director of Product</option><option>Omar H. · Engineering Manager</option><option>Khalid A. · Senior Product Manager</option></select></label>
        <label>Request type<select><option>Coffee chat</option><option>Referral</option><option>Resume feedback</option><option>Company insight</option></select></label>
        <label>Message<textarea placeholder="Write a short, thoughtful request..." /></label>
        <Button onClick={onClose}>Submit request <Send size={18}/></Button>
      </section>
    </div>
  );
}

function Referrals({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Referrals" title="Referral requests" action={<Button><Plus size={18}/> New request</Button>} />
      <div className="chips filter-chips">
        {["All", "Incoming", "Outgoing", "Pending", "Accepted", "Declined"].map(item => <button key={item}>{item}</button>)}
      </div>
      <div className="app-grid two">
        <Panel title="Send a referral request">
          <label>Target company<input placeholder="Amazon"/></label>
          <label>Target role<input placeholder="Operations Manager"/></label>
          <label>Select host<select><option>Khalid A. · Google</option><option>Aisha K. · Stripe</option><option>Omar H. · Meta</option></select></label>
          <label>Request type<select><option>Coffee chat</option><option>Referral</option><option>Resume feedback</option><option>Interview prep</option></select></label>
          <label>Message<textarea placeholder="Write a short, respectful ask."/></label>
          <Button>Submit request</Button>
        </Panel>
        <Panel title="Your requests">
          {referrals.map(ref => <ReferralCard key={ref.id} ref={ref}/>)}
        </Panel>
      </div>
    </AppShell>
  );
}

function Profile({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <section className="profile-hero">
        <Avatar initials="RA" className="profile"/>
        <div>
          <Badge>FOUNDING MEMBER</Badge>
          <h1>Rakan AlJboor</h1>
          <p>Operations and engineering professional building toward program management, logistics, and technology roles.</p>
          <div className="hero-actions left">
            <Button>Edit profile</Button>
            <Button variant="secondary">Share profile</Button>
          </div>
        </div>
      </section>

      <div className="app-grid two">
        <Panel title="Career story">
          <p>I help teams solve operational problems, improve systems, and launch scalable processes. I’m looking to connect with professionals in operations, engineering, and product-led organizations.</p>
        </Panel>
        <Panel title="Video intro">
          <div className="video-placeholder">
            <Play/>
            <strong>Add a 60-second intro</strong>
            <span>Show people who you are before the resume.</span>
          </div>
        </Panel>
      </div>

      <div className="app-grid two">
        <Panel title="Target roles">
          <div className="chips compact">{["Operations Analyst", "Program Manager", "Product Analyst", "Industrial Engineer"].map(item => <span key={item}>{item}</span>)}</div>
        </Panel>
        <Panel title="Skills">
          <div className="chips compact">{["Operations", "Power BI", "Excel", "Lean", "Logistics", "Data analysis", "Project management"].map(item => <span key={item}>{item}</span>)}</div>
        </Panel>
      </div>

      <Panel title="Referrals received">
        {referrals.slice(0,2).map(ref => <ReferralMini key={ref.id} ref={ref}/>)}
      </Panel>
    </AppShell>
  );
}

function HostDashboard({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Referral host" title="Help someone get seen." action={<Button>Set availability</Button>} />
      <Stats stats={[["3","Monthly capacity"],["7","Requests received"],["4","Accepted"],["2","Referrals made"]]} />
      <div className="app-grid two">
        <Panel title="Availability settings">
          <Checklist items={["Open to coffee chats", "Open to referrals", "Open to resume feedback"]} interactive/>
          <label>Monthly capacity<select><option>3 people/month</option><option>5 people/month</option><option>10 people/month</option></select></label>
          <label>Roles I can support<input placeholder="Product, operations, engineering..." /></label>
        </Panel>
        <Panel title="Host profile preview">
          <HostProfileCard/>
        </Panel>
      </div>
      <Panel title="Incoming requests">
        {referrals.map(ref => <RequestRow key={ref.id} ref={ref}/>)}
      </Panel>
    </AppShell>
  );
}

function RecruiterDashboard({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Recruiter dashboard" title="Create rooms and review referred talent." action={<Button><Plus size={18}/> Create Q&A room</Button>} />
      <Stats stats={[["4","Active rooms"],["38","Referred candidates"],["12","Shortlisted"],["5","Interviews scheduled"]]} />
      <div className="app-grid two">
        <Panel title="Create hiring room">
          <label>Room title<input placeholder="Operations Hiring Q&A"/></label>
          <label>Attached job<input placeholder="Operations Analyst"/></label>
          <label>Department<input placeholder="Operations"/></label>
          <label>Room format<select><option>Q&A</option><option>Coffee chat</option><option>Open house</option><option>Referral night</option></select></label>
          <Button>Create room</Button>
        </Panel>
        <Panel title="Candidate pipeline">
          {candidates.map(c => <CandidateRow key={c.name} c={c}/>)}
        </Panel>
      </div>
      <Panel title="Room performance">
        <div className="performance-grid">
          {["128 signups", "64% attendance", "42 questions", "18 referral requests", "7 shortlisted"].map(item => <div key={item}>{item}</div>)}
        </div>
      </Panel>
    </AppShell>
  );
}

function SettingsPage({ page, setPage }) {
  return (
    <AppShell page={page} setPage={setPage}>
      <AppTop eyebrow="Settings" title="Account settings"/>
      <div className="app-grid two">
        <Panel title="Profile settings">
          <label>Name<input defaultValue="Rakan AlJboor"/></label>
          <label>Email<input defaultValue="rakan@example.com"/></label>
          <Button>Save changes</Button>
        </Panel>
        <Panel title="Notifications">
          <Checklist items={["Referral request updates", "Room reminders", "Host availability alerts", "Weekly opportunity digest"]} interactive/>
        </Panel>
      </div>
    </AppShell>
  );
}

function Panel({ title, action, children }) {
  return (
    <section className="panel">
      <div className="panel-top">
        <h3>{title}</h3>
        {action}
      </div>
      {children}
    </section>
  );
}

function Stats({ stats }) {
  return (
    <div className="stats">
      {stats.map(([num, label]) => (
        <div className="stat" key={label}>
          <strong>{num}</strong>
          <span>{label}</span>
        </div>
      ))}
    </div>
  );
}

function MiniRoom({ room, setPage }) {
  return (
    <div className="mini-row">
      <div>
        <strong>{room.title}</strong>
        <span>{room.category} · {room.attendees} attending</span>
      </div>
      <button onClick={() => setPage("roomDetail")}><ChevronRight/></button>
    </div>
  );
}

function ReferralMini({ ref }) {
  return (
    <div className="mini-row">
      <div>
        <strong>{ref.name}</strong>
        <span>{ref.type} · {ref.target}</span>
      </div>
      <Status status={ref.status}/>
    </div>
  );
}

function HostMini({ host }) {
  return (
    <article className="host-mini">
      <Avatar initials={host.avatar}/>
      <strong>{host.name}</strong>
      <span>{host.role} @ {host.company}</span>
      <small>{host.capacity}</small>
      <Button variant="secondary">Request chat</Button>
    </article>
  );
}

function Checklist({ items, interactive = false }) {
  return (
    <div className="checklist">
      {items.map((item, index) => (
        <div key={item}>
          <span className={interactive || index < 3 ? "checked" : ""}>{(interactive || index < 3) && <Check size={14}/>}</span>
          {item}
        </div>
      ))}
    </div>
  );
}

function Timeline({ items }) {
  return (
    <div className="timeline">
      {items.map((item, index) => (
        <div key={item}>
          <span>{index + 1}</span>
          <p>{item}</p>
        </div>
      ))}
    </div>
  );
}

function HostLine({ host }) {
  return (
    <div className="host-line">
      <Avatar initials={host.avatar} className="small"/>
      <div>
        <strong>{host.name}</strong>
        <span>{host.role} @ {host.company}</span>
      </div>
      <Badge>{host.capacity}</Badge>
    </div>
  );
}

function ReferralCard({ ref }) {
  return (
    <article className="referral-card">
      <div className="request-profile">
        <Avatar initials={ref.avatar} className="small"/>
        <div>
          <strong>{ref.name}</strong>
          <span>{ref.target}</span>
        </div>
      </div>
      <p>{ref.note}</p>
      <div className="referral-bottom">
        <Status status={ref.status}/>
        <span>{ref.lastUpdated}</span>
        <button>View</button>
      </div>
    </article>
  );
}

function Status({ status }) {
  return <span className={`status ${status.toLowerCase()}`}>{status}</span>;
}

function RequestRow({ ref }) {
  return (
    <div className="request-row">
      <div className="request-profile">
        <Avatar initials={ref.avatar} className="small"/>
        <div>
          <strong>{ref.name}</strong>
          <span>{ref.target}</span>
          <p>{ref.note}</p>
        </div>
      </div>
      <div className="row-actions">
        <Button variant="secondary"><XCircle size={16}/> Decline</Button>
        <Button><Check size={16}/> Accept</Button>
      </div>
    </div>
  );
}

function CandidateRow({ c }) {
  return (
    <div className="candidate-row">
      <div className="request-profile">
        <Avatar initials={c.avatar} className="small"/>
        <div>
          <strong>{c.name}</strong>
          <span>{c.role}</span>
          <small>Referral source: {c.source}</small>
        </div>
      </div>
      <div className="candidate-tags">
        {c.tags.map(t => <span key={t}>{t}</span>)}
      </div>
      <div>
        <Badge>{c.fit} fit</Badge>
        <Status status={c.status}/>
      </div>
    </div>
  );
}

function App() {
  const [page, setPage] = useState("landing");
  const publicPages = ["landing", "login", "signup", "onboarding"];

  const routes = {
    landing: <Landing setPage={setPage}/>,
    login: <AuthPage type="login" setPage={setPage}/>,
    signup: <AuthPage type="signup" setPage={setPage}/>,
    onboarding: <Onboarding setPage={setPage}/>,
    dashboard: <Dashboard page={page} setPage={setPage}/>,
    rooms: <RoomsPage page={page} setPage={setPage}/>,
    roomDetail: <RoomDetail page={page} setPage={setPage}/>,
    liveRoom: <LiveRoom page={page} setPage={setPage}/>,
    referrals: <Referrals page={page} setPage={setPage}/>,
    profile: <Profile page={page} setPage={setPage}/>,
    host: <HostDashboard page={page} setPage={setPage}/>,
    recruiter: <RecruiterDashboard page={page} setPage={setPage}/>,
    settings: <SettingsPage page={page} setPage={setPage}/>
  };

  return (
    <>
      {publicPages.includes(page) && <PublicHeader setPage={setPage} page={page}/>}
      {routes[page]}
      {publicPages.includes(page) && (
        <footer className="footer">
          <Logo compact/>
          <p>Real people. Real referrals. Real growth.</p>
          <div>
            <button>Privacy</button>
            <button>Terms</button>
            <button>LinkedIn</button>
          </div>
        </footer>
      )}
    </>
  );
}

createRoot(document.getElementById("root")).render(<App />);
